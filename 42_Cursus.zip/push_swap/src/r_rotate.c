/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   r_rotate.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:34:39 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:34:41 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	r_rotate_a(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->a[stacks->i - 1];
	i = 0;
	while (i < stacks->i - 1)
	{
		stacks->a[stacks->i - (i + 1)] = stacks->a[stacks->i - (i + 2)];
		i++;
	}
	stacks->a[0] = temp;
}

void	r_rotate_b(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->b[stacks->len - stacks->i - 1];
	i = 0;
	while (i < (stacks->len - stacks->i - 1))
	{
		stacks->b[stacks->len - stacks->i - (i + 1)] = stacks->b[stacks->len
			- stacks->i - (i + 2)];
		i++;
	}
	stacks->b[0] = temp;
}

void	r_ra_rb(t_stack *stacks)
{
	r_rotate_a(stacks);
	r_rotate_b(stacks);
}
