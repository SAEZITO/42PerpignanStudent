/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:32:23 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:33:26 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

int	is_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	while ((i + 1) < stacks->len)
	{
		if (stacks->a[i] > stacks->a[i + 1])
			return (0);
		i++;
	}
	return (1);
}

void	algo_one(t_stack *stacks)
{
	//compare 1st, 2nd and last ints and decide which op is best
	if (stacks->a[0] < stacks->a[1])
	{
		if (stacks->a[0] < stacks->a[stacks->i - 1])
		{
			push_b(stacks);
		}
		else
			r_rotate_a(stacks);
	}
	else
		swap_a(stacks);
}
