/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:34:08 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:34:10 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	push_a(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->b[0];
	i = 0;
	if (stacks->i < stacks->len)
	{
		while (i < stacks->len - 1)
		{
			stacks->a[stacks->len - (i + 1)] = stacks->a[stacks->len - (i + 2)];
			stacks->b[i] = stacks->b[i + 1];
			i++;
		}
		stacks->b[stacks->i - 1] = 0;
		stacks->i++;
		stacks->a[0] = temp;
	}
}

void	push_b(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->a[0];
	i = 0;
	if (stacks->i > 0)
	{
		while (i < stacks->len - 1)
		{
			stacks->b[stacks->len - (i + 1)] = stacks->b[stacks->len - (i + 2)];
			stacks->a[i] = stacks->a[i + 1];
			i++;
		}
		stacks->a[stacks->i - 1] = 0;
		stacks->i--;
		stacks->b[0] = temp;
	}
}
