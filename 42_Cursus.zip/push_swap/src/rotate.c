/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rotate.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:34:23 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:34:25 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	rotate_a(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->a[0];
	i = 0;
	while (i < stacks->i - 1)
	{
		stacks->a[i] = stacks->a[i + 1];
		i++;
	}
	stacks->a[stacks->i - 1] = temp;
}

void	rotate_b(t_stack *stacks)
{
	int	i;
	int	temp;

	temp = stacks->b[0];
	i = 0;
	while (i < (stacks->len - stacks->i - 1))
	{
		stacks->b[i] = stacks->b[i + 1];
		i++;
	}
	stacks->b[(stacks->len - stacks->i) - 1] = temp;
}

void	ra_rb(t_stack *stacks)
{
	rotate_a(stacks);
	rotate_b(stacks);
}
