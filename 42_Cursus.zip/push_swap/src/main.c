/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:32:23 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:33:08 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

int	main(int argc, char **argv)
{
	t_stack	stacks;
	int		i;

	if (!make_stacks(&stacks, argc, argv))
		return (0);
	i = 0;
	while (i < stacks.len)
	{
		printf("a :%d \t b :%d\n", stacks.a[i], stacks.b[i]);
		i++;
	}
	//free(stacks->a);
	//free(stacks->b);
	return (0);
}
