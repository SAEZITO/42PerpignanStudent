/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:35:20 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:35:24 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "../libft/libft.h"

typedef struct s_stack
{
	int	*a;
	int	*b;
	int	i;
	int	len;

} t_stack;

void	push_a(t_stack *stacks);
void	push_b(t_stack *stacks);
void	swap_a(t_stack *stacks);
void	swap_b(t_stack *stacks);
void	sswap(t_stack *stacks);
int	make_stacks(t_stack *stacks, int argc, char **argv);
void	fill_a(t_stack *stacks, char **argv);
void	fill_a_split(t_stack *stacks, char **splitted);
void	rotate_b(t_stack *stacks);
void	rotate_a(t_stack *stacks);
void	ra_rb(t_stack *stacks);
void	r_rotate_b(t_stack *stacks);
void	r_rotate_a(t_stack *stacks);
void	r_ra_rb(t_stack *stacks);
int	is_sorted(t_stack *stacks);
void	algo_one(t_stack *stacks);


#endif
