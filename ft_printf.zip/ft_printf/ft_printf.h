/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/22 14:31:20 by alsaez            #+#    #+#             */
/*   Updated: 2023/02/22 17:12:41 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

#include "./libft/libft.h"
#include<stdarg.h>
#include<stdint.h>

int	ft_printform(va_list vars, const char format);
int	ft_print_ptr(unsigned long ptr);
int	ft_print_nbr(int nbr);

#endif
