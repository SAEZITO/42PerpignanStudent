/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/02/22 11:31:07 by alsaez            #+#    #+#             */
/*   Updated: 2023/02/22 17:35:59 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_printform(va_list vars, const char format, int print_len)
{
	if (format == 'c')
	{
		print_len += 1;
		ft_putchar_fd(va_arg(vars, int), 1);
	}
	if (format == 's')
	{
		print_len += ft_strlen(va_arg(vars, char *));
		ft_putstr_fd(va_arg(vars, char *), 1);
	}
	if (format == 'p')
		print_len += ft_print_ptr(va_arg(vars, unsigned long));
	if (format == 'd')
		print_len += ft_print_nbr(va_arg(vars, int));
	if (format == 'u')
		print_len += ft_print_usd(va_arg(vars, unsigned int));
	if (format == 'x' || format == 'X')
		print_len += ft_print_hex(va_arg(vars, unsigned int), format);
	if (format == '%')
		print_len += ft_print_pct();
	return (print_len);
}

int	ft_printf(const char *str, ...)
{
	va_list	vars;
	int		print_len;

	print_len = 0;
	va_start(vars, str);
	while (str)
	{
		if (str == '%')
			ft_printform(vars, str++, &print_len);
		else
		{
			print_len++;
			ft_putchar_fd(*str, 1);
			str++;
		}
	}
	va_end(vars);
	return (print_len);
}
