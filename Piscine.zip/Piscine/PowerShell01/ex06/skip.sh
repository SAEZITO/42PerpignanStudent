ls -l | sed '2~2d'
