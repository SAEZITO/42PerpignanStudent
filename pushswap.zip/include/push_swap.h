/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:35:20 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:35:24 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include "../libft/libft.h"

typedef struct s_stack
{
	int	*a;
	int	*b;
	int	index;
	int	len;
	int	*order;
	int	mid;
	int	max;
	int min;
	int	q1;
	int	q3;
	int p1;
	int p2;
	int p3;
	int p4;
	int p6;
	int p7;
	int p8;
	int p9;
} t_stack;

void	push_a(t_stack *stacks);
void	push_b(t_stack *stacks);
void	swap_a(t_stack *stacks, int flag);
void	swap_b(t_stack *stacks, int flag);
void	sswap(t_stack *stacks);
int	make_stacks(t_stack *stacks, int argc, char **argv);
void	fill_a(t_stack *stacks, char **argv);
void	fill_a_split(t_stack *stacks, char **splitted);
void	rotate_b(t_stack *stacks, int flag);
void	rotate_a(t_stack *stacks, int flag);
void	ra_rb(t_stack *stacks);
void	r_rotate_b(t_stack *stacks, int flag);
void	r_rotate_a(t_stack *stacks, int flag);
void	r_ra_rb(t_stack *stacks);
int	is_sorted(t_stack *stacks);
void	algo_one(t_stack *stacks);
void    make_index(t_stack *stacks);
void	algo_two(t_stack *stacks);
void	algo_three(t_stack *stacks);
void	algo_four(t_stack *stacks);
int	is_b_sorted(t_stack *stacks);
int	is_a_sorted(t_stack *stacks);
int	is_b_r_sorted(t_stack *stacks);
void		push_high_q(t_stack *stacks);
void		push_medhg_q(t_stack *stacks);
void		push_medlw_q(t_stack *stacks);
void		push_low_q(t_stack *stacks);
void 		sort_last_q(t_stack *stacks);
void 		sort_first_q(t_stack *stacks);
void 		sort_second_q(t_stack *stacks);
void 		sort_third_q(t_stack *stacks);


#endif
