/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:34:54 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:35:00 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	swap_a(t_stack *stacks, int flag)
{
	int temp;

	if (stacks->index <= 1)
		return ;
	temp = stacks->a[0];
	stacks->a[0] = stacks->a[1];
	stacks->a[1] = temp;
	if (flag != 1)
		write(1, "sa\n", 3);
}

void	swap_b(t_stack *stacks, int flag)
{
	int temp;

	if ((stacks->len - stacks->index) <= 1)
		return ;
	temp = stacks->b[0];
	stacks->b[0] = stacks->b[1];
	stacks->b[1] = temp;
	if (flag != 1)
		write(1, "sb\n", 3);
}

void	sswap(t_stack *stacks)
{
	int	flag;

	flag = 1;
	swap_a(stacks, flag);
	swap_b(stacks, flag);
	write(1, "ss\n", 3);
}

