/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:32:23 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:33:26 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

int	is_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	if (stacks->index == stacks->len)
	{
		while ((i + 1) < stacks->len)
		{
			if (stacks->a[i] < stacks->a[i + 1])
				i++;	
			else
				return (0);
		}
		return (1);
	}
	else
		return (0);
}

int	is_a_r_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	if (stacks->index <= 1)
		return (1);
	while ((i + 1) < stacks->index)
	{
		if (stacks->a[i] > stacks->a[i + 1])
			i++;
		else
			return (0);
	}
	return (1);
}

int	is_b_r_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	if (stacks->len - stacks->index <= 1)
		return (1);
	while ((i + 1) < (stacks->len - stacks->index))
	{
		if (stacks->b[i] > stacks->b[i + 1])
			i++;
		else
			return (0);
	}
	return (1);
}

int	is_b_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	if (stacks->len - stacks->index <= 1)
		return (1);
	while ((i + 1) < (stacks->len - stacks->index))
	{
		if (stacks->b[i] < stacks->b[i + 1])
			i++;
		else
			return (0);
	}
	return (1);
}

int	is_a_sorted(t_stack *stacks)
{
	int	i;

	i = 0;
	if (stacks->index <= 1)
		return (1);
	while ((i + 1) < stacks->index)
	{
		if (stacks->a[i] < stacks->a[i + 1])
			i++;
		else
			return (0);
	}
	return (1);
}