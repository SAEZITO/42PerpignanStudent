/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/30 16:32:23 by alsaez            #+#    #+#             */
/*   Updated: 2023/03/30 16:33:08 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

int	main(int argc, char **argv)
{
	t_stack	stacks;
	
	if (!make_stacks(&stacks, argc, argv))
		return (0);
	else
		make_index(&stacks);
	if (!is_sorted(&stacks))
	{
		algo_four(&stacks);
		ft_printf("test1\n");
	}
	/*swap_a(&stacks, 0);
	push_b(&stacks);
	swap_a(&stacks, 0);
	push_b(&stacks);
	swap_b(&stacks, 0);
	push_b(&stacks);
	push_b(&stacks);
	push_a(&stacks);
	//push_a(&stacks);
	//push_a(&stacks);
	//push_a(&stacks);
	//swap_a(&stacks, 0);*/
	/*i = 0;
	while (i < stacks.len)
	{
		printf("a :%d \t b :%d \t o :%d\n", stacks.a[i], stacks.b[i], stacks.order[i]);
		i++;
	}*/
	free(stacks.a);
	free(stacks.b);
	free(stacks.order);
	return (0);
}
