/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/03 15:56:24 by alsaez            #+#    #+#             */
/*   Updated: 2023/04/03 15:56:59 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void    make_index(t_stack *stacks)
{
        int     i;
        int     j;
        int     index;
        
        i = 0;
        j = 0;
        index = 1;
        stacks->order = ft_calloc(stacks->len + 1, sizeof(int));
        while (i < stacks->len)
        {
                while (j < stacks->len)
                        if (stacks->a[i] < stacks->a[j++])
                                index++;
                stacks->order[stacks->len - index] = stacks->a[i];
                j = 0;
                index = 1;
                i++;
        }
        stacks->q3 = stacks->order[stacks->len / 2 + stacks->len / 4];
        stacks->q1 = stacks->order[stacks->len / 4];
        stacks->mid = stacks->order[stacks->len / 2];
        stacks->min = stacks->order[0];
        stacks->max = stacks->order[stacks->len - 1];
        stacks->order[stacks->len] = '\0';
}

void		push_high_q(t_stack *stacks)
{
	int		i;
	int		j;

	j = (stacks->index - 1);
	i = 0;
	while (stacks->index >= (stacks->len / 4  + stacks->len / 2) &&  i < stacks->index)
	{	
		if (stacks->a[i] >= stacks->q3)
		{
			while (i-- > 0)
			{
				if (stacks->b[0] > stacks->order[((stacks->len / 4) * 3) + (stacks->len / 8)] && stacks->b[0] < stacks->order[(stacks->len - 1) - stacks->len / 8])
					ra_rb(stacks);
				else
					rotate_a(stacks, 0);
			}
			if ((stacks->a[0] == stacks->q3 || stacks->a[0] == stacks->max) && stacks->index == (stacks->len / 4  + stacks->len / 2))
				return;
			else
				push_b(stacks);
			j = stacks->index;
		}
		if (stacks->a[j] >= stacks->q3)
		{
			while (j++ != stacks->index)
			{	
				if (stacks->b[0] > stacks->order[((stacks->len / 4) * 3) + (stacks->len / 8)] && stacks->b[0] < stacks->order[stacks->len - stacks->len / 8])
					r_ra_rb(stacks);
				else
					r_rotate_a(stacks, 0);
			}
			if ((stacks->a[0] == stacks->q3 || stacks->a[0] == stacks->max) && stacks->index == (stacks->len / 4  + stacks->len / 2))
				return;
			else
				push_b(stacks);
			i = -1;
        }
		i++;
		j--;
	}
}

void		push_medhg_q(t_stack *stacks)
{
	int		i;
	int		j;

	j = (stacks->index - 1);
	i = 0;
	while (stacks->index >= (stacks->len / 4 + stacks->len / 2) &&  i < stacks->index)
	{	
		if (stacks->a[i] >= stacks->mid && stacks->a[i] < stacks->q3)
		{
			while (--i >= 0)
				rotate_a(stacks, 0);
			if ((stacks->a[0] == stacks->mid || stacks->a[0] == stacks->order[(stacks->len / 2) + (stacks->len / 4) - 1]) && stacks->index == (stacks->len / 4) * 3)
				return;
			else
				push_b(stacks);
			j = stacks->index;
		}
		if (stacks->a[j] >= stacks->mid && stacks->a[j] < stacks->q3)
		{
			while (j++ != stacks->index)
				r_rotate_a(stacks, 0);
			if ((stacks->a[0] == stacks->mid || stacks->a[0] == stacks->order[(stacks->len / 2) + (stacks->len / 4) - 1]) && stacks->index == (stacks->len / 4) * 3)
				return;
			else
				push_b(stacks);
			i = -1;
		}
		i++;
		j--;
	}
}

void		push_medlw_q(t_stack *stacks)
{
	int		i;
	int		j;

	j = stacks->index - 1;
	i = 0;
	while (stacks->index >= (stacks->len / 4 + stacks->len / 2) &&  i < stacks->index)
	{	
		if ((stacks->a[0] == stacks->order[(stacks->len / 2) - 1] || stacks->a[0] == stacks->q1) && stacks->index == ((stacks->len / 4) * 3) + 1)
				break;
		if (stacks->a[i] < stacks->mid && stacks->a[i] >= stacks->q1)
		{
			while (--i >= 0)
				rotate_a(stacks, 0);
			push_b(stacks);
			j = stacks->index;
		}
		if (stacks->a[j] < stacks->mid && stacks->a[j] >= stacks->q1)
		{
			while (j++ != stacks->index)
				r_rotate_a(stacks, 0);
			push_b(stacks);
			i = -1;
		}
		i++;
		j--;
	}
}

void		push_low_q(t_stack *stacks)
{
	int		i;

	i = 0;
	while (stacks->index >= (stacks->len / 4 + stacks->len / 2) &&  i < stacks->index)
	{	
		if (stacks->a[i] < stacks->q1 && (i <= stacks->index / 2))
		{
			while (--i >= 0)
				rotate_a(stacks, 0);
			push_b(stacks);
		}
		if (stacks->a[i] < stacks->q1 && (i > stacks->index / 2))
		{
			while (i++ < stacks->index)
				r_rotate_a(stacks, 0);
			push_b(stacks);
			i = -1;
		}
		i++;
	}
}