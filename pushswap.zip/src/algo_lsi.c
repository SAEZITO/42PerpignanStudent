/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_lsi.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/03 15:27:51 by alsaez            #+#    #+#             */
/*   Updated: 2023/04/03 15:28:24 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void    init_lsi(t_lsi *lsi)
{
    lsi->end
}
int     algo_lsi(t_stack *stacks)
{
    t_lsi   lsi;
    int     len_lsi;
    int     i;
    int     j;

    i = 0;
    j = 1;
    len_lsi = 0;
    init_lsi(&lsi);
    while (stacks->a[i])
    {
        while (stacks->a[j])
        {
            if ((stacks->a[i] < stacks->a[j]))
            {
                len_lsi += i;
                i++;
            
            }
            j++;
        }

        i++;
    }
    
}