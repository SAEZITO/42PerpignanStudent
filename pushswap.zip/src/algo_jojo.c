/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_jojo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/03 15:56:24 by alsaez            #+#    #+#             */
/*   Updated: 2023/04/03 15:56:59 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	algo_three(t_stack *stacks)
{
    int     i;
    int     j;
    int     k;
    int     l;

    j = (stacks->index - 1);
	i = 0;
    while (stacks->index > stacks->len / 2)
    {
	    if (stacks->a[i] >= stacks->q1 && stacks->a[i] < stacks->q3)
		{
			while (i-- > 0)
				rotate_a(stacks, 0);
			j = stacks->index;
	        push_b(stacks);
        }
		else if (stacks->a[j] >= stacks->q1 && stacks->a[j] < stacks->q3)
		{
			while (j++ != stacks->index)
				r_rotate_a(stacks, 0);
			i = -1;
    	    push_b(stacks);
        }
        if (stacks->b[0] >= stacks->q1 && stacks->b[0] < stacks->mid && (stacks->len - stacks->index) >= 2)
        {
            rotate_b(stacks, 0);
        }
		i++;
		j--;
	}
    while (stacks->index > 0)
    {
        push_b(stacks);
        if (stacks->b[0] < stacks->q1)
        {
            rotate_b(stacks, 0);
        }
	}
    k = 0;
    l = 1;
    while (stacks->len - stacks->index > (stacks->len / 4) * 3)
    {
        i = 0;
        j = stacks->len - 1;
    	while ((stacks->b[i] != stacks->order[stacks->len - l]) && (stacks->b[i] != stacks->order[((stacks->len / 4) * 3) + k]))
    		i++;
    	while ((stacks->b[j] != stacks->order[stacks->len - l]) && (stacks->b[j] != stacks->order[((stacks->len / 4) * 3) + k]))
    		j--;
    	if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 4) * 3) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 4) * 3) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
    }
    while (stacks->a[0] != stacks->q3)
    {
        if ((stacks->b[0] != stacks->order[(stacks->len / 4) * 3 - 1]) && (stacks->b[i] != stacks->order[stacks->len / 2]))
            ra_rb(stacks);
        else
            rotate_a(stacks, 0);
    }
    k = 0;
    l = 1;
    while (stacks->len - stacks->index > stacks->len / 2)
    {
        i = 0;
        j = stacks->len - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 4) * 3) - l]) && (stacks->b[i] != stacks->order[(stacks->len / 2) + k]))
    		i++;
    	while ((stacks->b[j] != stacks->order[((stacks->len / 4) * 3) - l]) && (stacks->b[j] != stacks->order[(stacks->len / 2) + k]))
    		j--;
    	if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[(stacks->len / 2) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[(stacks->len / 2) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
    }
    while (stacks->a[0] != stacks->mid)
    {
        if ((stacks->b[0] != stacks->order[(stacks->len / 2) - 1]) && (stacks->b[i] != stacks->order[stacks->len / 4]))
            r_ra_rb(stacks);
        else
            r_rotate_a(stacks, 0);
    }
    k = 0;
    l = 1;
    while (stacks->len - stacks->index > stacks->len / 4)
    {
        i = 0;
        j = stacks->len - 1;
    	while ((stacks->b[i] != stacks->order[(stacks->len / 2) - l]) && (stacks->b[i] != stacks->order[(stacks->len / 4) + k]))
    		i++;
    	while ((stacks->b[j] != stacks->order[(stacks->len / 2) - l]) && (stacks->b[j] != stacks->order[(stacks->len / 4) + k]))
    		j--;
    	if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[(stacks->len / 4) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[(stacks->len / 4) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
    }
    while (stacks->a[0] != stacks->q1)
    {
        if ((stacks->b[0] != stacks->order[(stacks->len / 4) - 1]) && (stacks->b[i] != stacks->order[0]))
            r_ra_rb(stacks);
        else
            r_rotate_a(stacks, 0);
    }
    k = 0;
    l = 1;
    while (stacks->len - stacks->index > 0)
    {
        i = 0;
        j = stacks->len - 1;
    	while ((stacks->b[i] != stacks->order[(stacks->len / 4) - l]) && (stacks->b[i] != stacks->order[k]))
    		i++;
    	while ((stacks->b[j] != stacks->order[(stacks->len / 4) - l]) && (stacks->b[j] != stacks->order[k]))
    		j--;
    	if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
    }
    while (stacks->a[0] != stacks->min)
    {
        r_rotate_a(stacks, 0);
    }
}

void	algo_four(t_stack *stacks)
{
    int     i;
    int     j;

    j = (stacks->index - 1);
	i = 0;
    while (stacks->index > stacks->len / 2)
    {
	    if ((stacks->a[i] >= stacks->q3) || (stacks->a[i] < stacks->mid && stacks->a[i] >= stacks->q1))
		{
			while (i-- > 0)
				rotate_a(stacks, 0);
			j = stacks->index;
	        push_b(stacks);
        }
		else if ((stacks->a[j] >= stacks->q3) || (stacks->a[j] < stacks->mid && stacks->a[j] >= stacks->q1))
		{
			while (j++ != stacks->index)
				r_rotate_a(stacks, 0);
			i = -1;
    	    push_b(stacks);
        }
        if (stacks->b[0] < stacks->mid && (stacks->len - stacks->index) >= 2)
        {
            if (stacks->a[0] < stacks->mid)
                ra_rb(stacks);
            else
                rotate_b(stacks, 0);
        }
        if (stacks->b[0] < stacks->b[1])
        {
            if (stacks->a[0] < stacks->a[1])
                sswap(stacks);
            else            
                swap_b(stacks, 0);
        }
		i++;
		j--;
	}
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index > stacks->len / 4)
            sort_first_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
    while (stacks->a[0] >= stacks->q3)
    {
        if (stacks->b[0] != stacks->mid && stacks->b[stacks->len - stacks->index] != stacks->mid)
        {
            ra_rb(stacks);
        }
        else
            rotate_a(stacks, 0);
    }
    j = (stacks->index - 1);
	i = 0;
    while (stacks->index >= stacks->len / 4)
    {
	    push_b(stacks);
        if (stacks->b[0] <= stacks->q1)
            rotate_b(stacks, 0);
        if (stacks->b[0] < stacks->b[1])
        {
            if (stacks->a[0] < stacks->a[1])
                sswap(stacks);
            else            
                swap_b(stacks, 0);
        }
		i++;
		j--;
	}   
    return;
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index >= stacks->len / 2)
            sort_second_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}/*
    while (stacks->a[0] > stacks->mid)
    {
        r_rotate_a(stacks, 0);
    }*/
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index >= stacks->len / 4)
            sort_third_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}/*
    while (stacks->a[0] != stacks->q1)
    {
        r_rotate_a(stacks, 0);
    }*/
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index > 0)
            sort_last_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
/*    while (stacks->a[0] != stacks->min)
    {
        r_rotate_a(stacks, 0);
    }
 */   
    
    
}