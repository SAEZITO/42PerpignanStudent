/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_jojo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/03 15:56:24 by alsaez            #+#    #+#             */
/*   Updated: 2023/04/03 15:56:59 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"

void	algo_three(t_stack *stacks)
{
    int     i;
    int     j;
    int     k;
    int     l;

	i = -1;
    while (stacks->index >= ((stacks->len / 10) * 4) && i < stacks->index)
    {
		i++;
	    if (stacks->a[i] <= stacks->p6)
		{
			while (i-- > 0)
				rotate_a(stacks, 0);
			push_b(stacks);
        }
        if ((stacks->b[0] > stacks->p1 && stacks->b[0] <= stacks->p2 && (stacks->len - stacks->index) >= 2) || (stacks->b[0] > stacks->p4 && stacks->b[0] <= stacks->mid && (stacks->len - stacks->index) >= 2))
        {
			if (stacks->a[0] > stacks->p6)
				ra_rb(stacks);
			else
			    rotate_b(stacks, 0);
		}
	}
	i = -1;
    while (stacks->index >= (stacks->len / 10) * 3 && i < stacks->index)
    {
		i++;
   		if (stacks->a[i] > stacks->p6 && stacks->a[i] <= stacks->p7)
   		{
    		while (i-- > 0)
   				rotate_a(stacks, 0);
			push_b(stacks);
		}
    }
	i = -1;
    while (stacks->index >= (stacks->len / 10) * 2 && i < stacks->index)
    {
		i++;
   		if (stacks->a[i] > stacks->p7 && stacks->a[i] <= stacks->p8)
   		{
    		while (i-- > 0)
   				rotate_a(stacks, 0);
			push_b(stacks);
		}
    }
	i = -1;
    while (stacks->index >= (stacks->len / 10) && i < stacks->index)
    {
		i++;
   		if (stacks->a[i] > stacks->p8 && stacks->a[i] <= stacks->p9)
   		{
    		while (i-- > 0)
   				rotate_a(stacks, 0);
			push_b(stacks);
		}
    }
	l = 1;
	while (stacks->index > 2)
	{
		i = 0;
		j = stacks->index - 1;
    	while (stacks->a[i] != stacks->order[((stacks->len / 10) * 9) + l])
    	{	i++;}
    	while (stacks->a[j] != stacks->order[((stacks->len / 10) * 9) + l])
    	{	j--;}
		if (i + j < (stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_a(stacks, 0);
    		if (stacks->a[0] == stacks->order[((stacks->len / 10) * 9) + l])
    		{
    			l++;
    			push_b(stacks);
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->index))
	    		r_rotate_a(stacks, 0);
	    	if (stacks->a[0] == stacks->order[((stacks->len / 10) * 9) + l])
	    	{
	    		l++;
	    		push_b(stacks);
	    	}
		}	
	}
	if (stacks->a[0] > stacks->a[1])
	{
		swap_a(stacks, 0);
	}
	while (stacks->b[0] > stacks->p9)
	{
		push_a(stacks);
	}
	l = 0;
	k = 1;
	j = 1;
	while (stacks->index <= ((stacks->len / 10) * 2) && i < stacks->len - stacks->index && j > 0)
	{
		i = 0;
        j = stacks->len - stacks->index - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 9) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 8) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 9) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 8) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 8) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 8) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[(stacks->index - 1)] != stacks->max)
	{
		r_rotate_a(stacks, 0);
	}
	l = 0;
	k = 1;
	j = 1;
	i = 0;
	while (stacks->index <= ((stacks->len / 10) * 3) && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = stacks->len - stacks->index - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 8) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 7) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 8) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 7) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 7) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 7) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[(stacks->index - 1)] != stacks->max)
	{
		r_rotate_a(stacks, 0);
	}
	i = 0;
	l = 0;
	k = 1;
	j = 1;
	while (stacks->index <= ((stacks->len / 10) * 4) && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 7) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 6) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 7) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 6) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 6) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 6) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[(stacks->index - 1)] != stacks->max)
	{
		r_rotate_a(stacks, 0);
	}
	k = 0;
	while (stacks->index < (stacks->len / 10 * 6))
	{	
		if (stacks->b[0] <= stacks->p1 || stacks->b[0] > stacks->mid)
			push_a(stacks);
		else
			rotate_b(stacks, 0);
		if (stacks->a[0] == stacks->order[k])
		{
			rotate_a(stacks, 0);
			k++;
		}
	}
	while (stacks->index > (stacks->len / 10 * 5))
	{	
		if (stacks->a[0] == stacks->order[k])
		{
			rotate_a(stacks, 0);
			k++;
		}
		if (stacks->a[0] > stacks->mid && stacks->a[0] <= stacks->p6)
    	{
    		push_b(stacks);
    	}
		else
			rotate_a(stacks, 0);
	}
	while (stacks->a[0] < stacks->p2)
	{
		rotate_a(stacks, 0);
	}
	i = 0;
	l = 0;
	k = 1;
	j = 1;
	while (stacks->index <= ((stacks->len / 10) * 6) && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 6) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 5) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 6) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 5) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 5) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 5) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] > stacks->p1)
	{
		r_rotate_a(stacks, 0);
	}
	i = 0;
	l = 0;
	k = 1;
	j = 1;
	while ((stacks->b[0] <= stacks->p2 || stacks->b[0] > stacks->p4) || (stacks->b[1] <= stacks->p2 || stacks->b[1] > stacks->p4))
	{
		if(stacks->b[0] <= stacks->p2)
		{
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else if (stacks->b[0] == stacks->order[(stacks->len / 10) * 5] - l)
		{
			push_a(stacks);
			l++;
		}
		else
			rotate_b(stacks, 0);
	}
	i = 0;
	k = 1;
	j = 1;
	while (stacks->index <= ((stacks->len / 10) * 8) && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 5) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 4) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 5) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 4) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 4) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 4) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] > stacks->p2)
	{
		r_rotate_a(stacks, 0);
	}
	i = 0;
	l = 0;
	k = 1;
	j = 1;
	while (stacks->len - stacks->index > ((stacks->len / 10) - l))
	{
		if(stacks->b[0] <= stacks->p3)
		{
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else if (stacks->b[0] == stacks->order[(stacks->len / 10) * 4] - l)
		{
			push_a(stacks);
			l++;
		}
		else
			rotate_b(stacks, 0);
	}
	i = 0;
	k = 1;
	j = 1;
	while (stacks->index < stacks->len && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 4) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 3) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 4) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 3) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 3) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 3) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] > stacks->p3)
	{
		r_rotate_a(stacks, 0);
	}
	k = 0;
	while (stacks->a[stacks->index - 1] > stacks->p2)
	{
		r_rotate_a(stacks, 0);
		if (stacks->a[0] != stacks->order[((stacks->len / 10) * 3) - k])
		{
			push_b(stacks);
		}
		else
			k++;
	}
	i = 0;
	j = 1;
	l = k;
	k = 1;
	while (stacks->len - stacks->index > 0 && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 3) - l]) && (stacks->b[i] != stacks->order[((stacks->len / 10) * 2) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 3) - l]) && (stacks->b[j] != stacks->order[((stacks->len / 10) * 2) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[((stacks->len / 10) * 2) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[((stacks->len / 10) * 2) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] > stacks->p2)
	{
		r_rotate_a(stacks, 0);
	}
	k = 0;
	while (stacks->a[stacks->index - 1] > stacks->p1)
	{
		r_rotate_a(stacks, 0);
		if (stacks->a[0] != stacks->order[((stacks->len / 10) * 2) - k])
		{
			push_b(stacks);
		}
		else
			k++;
	}
	i = 0;
	j = 1;
	l = k;
	k = 1;
	while (stacks->len - stacks->index > 0 && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[((stacks->len / 10) * 2) - l]) && (stacks->b[i] != stacks->order[(stacks->len / 10) + k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[((stacks->len / 10) * 2) - l]) && (stacks->b[j] != stacks->order[(stacks->len / 10) + k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[(stacks->len / 10) + k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[(stacks->len / 10) + k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] > stacks->p1)
	{
		r_rotate_a(stacks, 0);
	}	
	k = 0;
	while (stacks->a[stacks->index - 1] <= stacks->p1)
	{
		r_rotate_a(stacks, 0);
		if (stacks->a[0] != stacks->order[(stacks->len / 10) - k])
		{
			push_b(stacks);
		}
		else
			k++;
	}
	i = 0;
	j = 1;
	l = k;
	k = 0;
	while (stacks->len - stacks->index > 0 && i < (stacks->len - stacks->index) && j > 0)
	{
		i = 0;
        j = (stacks->len - stacks->index) - 1;
    	while ((stacks->b[i] != stacks->order[(stacks->len / 10)- l]) && (stacks->b[i] != stacks->order[k]))
    	{	i++;}
    	while ((stacks->b[j] != stacks->order[(stacks->len / 10) - l]) && (stacks->b[j] != stacks->order[k]))
    	{	j--;}
		if (i + j < (stacks->len - stacks->index))
    	{
	    	while(i-- > 0)
    			rotate_b(stacks, 0);
    		if (stacks->b[0] == stacks->order[k])
    		{
    			k++;
    			push_a(stacks);
    			rotate_a(stacks, 0);
    		}
    		else
    		{
    			push_a(stacks);
    			l++;
    		}
    	}
    	else
    	{
    		while(j++ < (stacks->len - stacks->index))
	    		r_rotate_b(stacks, 0);
	    	if (stacks->b[0] == stacks->order[k])
	    	{
	    		k++;
	    		push_a(stacks);
	    		rotate_a(stacks, 0);
	    	}
	    	else
	    	{
	    		push_a(stacks);
    			l++;
    		}
    	}
	}
	while (stacks->a[stacks->index - 1] <= stacks->p1)
	{
		r_rotate_a(stacks, 0);
	}
}

/*
void	algo_four(t_stack *stacks)
{
    int     i;
    int     j;

    j = (stacks->index - 1);
	i = 0;
    while (stacks->index > stacks->len / 2)
    {
	    if ((stacks->a[i] >= stacks->q3) || (stacks->a[i] < stacks->mid && stacks->a[i] >= stacks->q1))
		{
			while (i-- > 0)
				rotate_a(stacks, 0);
			j = stacks->index;
	        push_b(stacks);
        }
		else if ((stacks->a[j] >= stacks->q3) || (stacks->a[j] < stacks->mid && stacks->a[j] >= stacks->q1))
		{
			while (j++ != stacks->index)
				r_rotate_a(stacks, 0);
			i = -1;
    	    push_b(stacks);
        }
        if (stacks->b[0] < stacks->mid && (stacks->len - stacks->index) >= 2)
        {
            if (stacks->a[0] < stacks->mid)
                ra_rb(stacks);
            else
                rotate_b(stacks, 0);
        }
        if (stacks->b[0] < stacks->b[1])
        {
            if (stacks->a[0] < stacks->a[1])
                sswap(stacks);
            else            
                swap_b(stacks, 0);
        }
		i++;
		j--;
	}
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index > stacks->len / 4)
            sort_first_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
    while (stacks->a[0] >= stacks->q3)
    {
        if (stacks->b[0] != stacks->mid && stacks->b[stacks->len - stacks->index] != stacks->mid && stacks->b[stacks->len - stacks->index] != stacks->q3 && stacks->b[0] != stacks->q3)
        {
            ra_rb(stacks);
        }
        else
            rotate_a(stacks, 0);
    }
    j = (stacks->index - 1);
	i = 0;
    while (stacks->index >= stacks->len / 4)
    {
	    push_b(stacks);
        if (stacks->b[0] <= stacks->q1)
            rotate_b(stacks, 0);
        if (stacks->b[0] < stacks->b[1])
        {
            if (stacks->a[0] < stacks->a[1])
                sswap(stacks);
            else            
                swap_b(stacks, 0);
        }
		i++;
		j--;
	}   
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index >= stacks->len / 2)
            sort_second_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
    while (stacks->a[0] > stacks->mid)
    {
        r_rotate_a(stacks, 0);
    }
    return;
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index >= stacks->len / 4)
            sort_third_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
    while (stacks->a[0] != stacks->q1)
    {
        r_rotate_a(stacks, 0);
    }
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index > 0)
            sort_last_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
    while (stacks->a[0] != stacks->min)
    {
        r_rotate_a(stacks, 0);
    } 
    
    
}*/