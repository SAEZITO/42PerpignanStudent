/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_utils2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: alsaez <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/04/03 15:56:24 by alsaez            #+#    #+#             */
/*   Updated: 2023/04/03 15:56:59 by alsaez           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../include/push_swap.h"
   
void sort_first_q(t_stack *stacks)
{
    int		i;
	int		j;
	static int k = 1;
	static int l = 0;

	i = 0;
	j = stacks->len - stacks->index - 1;
	while ((stacks->b[i] != stacks->order[(stacks->len / 4  + stacks->len / 2) + l]) && (stacks->b[i] != stacks->order[stacks->len - k]))
		i++;
	while ((stacks->b[j] != stacks->order[(stacks->len / 4  + stacks->len / 2) + l]) && (stacks->b[j] != stacks->order[stacks->len - k]))
		j--;
	if (i + j < (stacks->len - stacks->index))
	{
		while(i-- > 0)
			rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 4  + stacks->len / 2) + l])
		{
			l++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			k++;
		}
	}
	else
	{
		while(j++ < (stacks->len - stacks->index))
			r_rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 4  + stacks->len / 2) + l])
		{
			l++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			k++;
		}
	}
}

void sort_second_q(t_stack *stacks)
{
    int		i;
	int		j;
	static int m = 1;
	static int n = 0;

	i = 0;
	j = stacks->len - stacks->index - 1;
	while ((stacks->b[i] != stacks->order[(stacks->len / 4  + stacks->len / 2) - m]) && (stacks->b[i] != stacks->order[(stacks->len / 2) + n]))
		i++;
	while ((stacks->b[j] != stacks->order[(stacks->len / 4  + stacks->len / 2) - m]) && (stacks->b[j] != stacks->order[(stacks->len / 2) + n]))
		j--;
	if (i + j < (stacks->len - stacks->index))
	{
		while(i-- > 0)
			rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 2) + n])
		{
			n++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			m++;
		}
	}
	else
	{
		while(j++ < (stacks->len - stacks->index))
			r_rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 2) + n])
		{
			n++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			m++;
		}
	}
}

void sort_third_q(t_stack *stacks)
{
    int		i;
	int		j;
	static int o = 1;
	static int p = 0;

	i = 0;
	j = stacks->len - stacks->index - 1;
	while ((stacks->b[i] != stacks->order[(stacks->len / 2) - o]) && (stacks->b[i] != stacks->order[(stacks->len / 4) + p]))
		i++;
	while ((stacks->b[j] != stacks->order[(stacks->len / 2) - o]) && (stacks->b[j] != stacks->order[(stacks->len / 4) + p]))
		j--;
	if (i + j < (stacks->len - stacks->index))
	{
		while(i-- > 0)
			rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 4) + p])
		{
			p++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			o++;
		}
	}
	else
	{
		while(j++ < (stacks->len - stacks->index))
			r_rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[(stacks->len / 4) + p])
		{
			p++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			o++;
		}
	}
}

void sort_last_q(t_stack *stacks)
{
    int		i;
	int		j;
	static int q = 1;
	static int r = 0;

	i = 0;
	j = stacks->len - stacks->index - 1;
	while ((stacks->b[i] != stacks->order[(stacks->len / 4) - q]) && (stacks->b[i] != stacks->order[r]))
		i++;
	while ((stacks->b[j] != stacks->order[(stacks->len / 4) - q]) && (stacks->b[j] != stacks->order[r]))
		j--;
	if (i + j < (stacks->len - stacks->index))
	{
		while(i-- > 0)
			rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[r])
		{
			r++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			q++;
		}
	}
	else
	{
		while(j++ < (stacks->len - stacks->index))
			r_rotate_b(stacks, 0);
		if (stacks->b[0] == stacks->order[r])
		{
			r++;
			push_a(stacks);
			rotate_a(stacks, 0);
		}
		else
		{
			push_a(stacks);
			q++;
		}
	}
}

void	algo_two(t_stack *stacks)
{
	push_high_q(stacks);
    if (!is_b_r_sorted(stacks))
	{	
		while (stacks->len - stacks->index > 2)
            sort_first_q(stacks);
	}
	else
	{
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
	}
	if (stacks->len - stacks->index == 2)
	{
		if (stacks->b[0] < stacks->b[1])
		{
			swap_b(stacks, 0);
			push_a(stacks);
		}
		else
			push_a(stacks);
		push_a(stacks);
	}
	push_medhg_q(stacks);
	while (stacks->a[0] != stacks->q3)
		r_rotate_a(stacks, 0);
    if (!is_b_r_sorted(stacks))
    {
		while (stacks->len - stacks->index > 2)
            sort_second_q(stacks);
    }
    else
    {
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
    }
	if (stacks->len - stacks->index == 2)
	{
		if (stacks->b[0] < stacks->b[1])
		{
			swap_b(stacks, 0);
			push_a(stacks);
		}
		else
			push_a(stacks);
		push_a(stacks);
	}
	push_medlw_q(stacks);
    if (!is_b_r_sorted(stacks))
    {
        while (stacks->len - stacks->index > 0)
            sort_third_q(stacks);
    }    
    else
    {
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
    }
	push_low_q(stacks);
    if (!is_b_r_sorted(stacks))
    {
        while (stacks->len - stacks->index > 0)
            sort_last_q(stacks);
    }    
    else
    {
        while (stacks->len - stacks->index > 0)
            push_a(stacks);
    }
	while (stacks->a[0] != stacks->min)
		r_rotate_a(stacks, 0);
	return;
}